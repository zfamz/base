import baseFormItem from './baseFormItem/index.vue';

const components = {
  install: function(Vue) {
    Vue.component('baseFormItem', baseFormItem);
  }
};

export default components;
